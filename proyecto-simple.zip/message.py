mensajes = [
    {
        'usuario':'persona123',
        'asunto':'hola',
        'mensaje': 'Este es un saludo especial'
    },
    {
        'usuario': 'usuario987',
        'asunto': 'Adios',
        'mensaje': 'Este es un mensaje de despedida'
    }
]